package com.example.killaura.modules;

import com.example.killaura.core.BaseModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class KillAuraModule extends BaseModule {
    private final MinecraftClient client;
    private LivingEntity target;
    private long lastAttackTime = 0;
    private boolean isAttacking = false;

    private final double range = 4.5;
    private final double rotationSpeed = 0.5;
    private final boolean throughWalls = false;
    private final boolean onlyPlayers = true;
    private final long attackDelay = 200;

    public KillAuraModule() {
        super("KillAura", "Автоматическая атака ближайшего врага");
        this.client = MinecraftClient.getInstance();
        System.out.println("KillAuraModule created!");
    }

    @Override
    protected void onEnable() {
        System.out.println("KillAura ENABLED");
        isAttacking = true;
        if (client.player != null) {
            client.player.sendMessage(Text.of("§aKillAura enabled!"), false);
        }
    }

    @Override
    protected void onDisable() {
        System.out.println("KillAura DISABLED");
        isAttacking = false;
        target = null;
        if (client.player != null) {
            client.player.sendMessage(Text.of("§cKillAura disabled!"), false);
        }
    }

    @Override
    protected void onUpdate() {
        if (client.player == null || client.world == null) return;

        // Включение/выключение по правому Shift
        if (client.options.sneakKey.wasPressed()) {
            toggle();
            return;
        }

        if (!isAttacking) return;

        ClientPlayerEntity player = client.player;

        // Поиск цели
        target = findTarget(player);

        if (target == null) return;

        // Поворот к цели
        rotateTo(player, target);

        // Атака с задержкой
        long now = System.currentTimeMillis();
        if (now - lastAttackTime < attackDelay) return;

        // Атака
        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        lastAttackTime = now;
    }

    private LivingEntity findTarget(ClientPlayerEntity player) {
        List<LivingEntity> entities = new ArrayList<>();

        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (living == player) continue;
            if (!living.isAlive()) continue;
            if (living.getHealth() <= 0) continue;

            if (onlyPlayers && !(living instanceof PlayerEntity)) continue;

            // Проверка через стены
            if (!throughWalls && !player.canSee(living)) continue;

            // Дистанция
            double dist = player.distanceTo(living);
            if (dist > range) continue;

            entities.add(living);
        }

        if (entities.isEmpty()) return null;

        entities.sort(Comparator.comparingDouble(e -> player.distanceTo(e)));
        return entities.get(0);
    }

    private void rotateTo(ClientPlayerEntity player, LivingEntity target) {
        double dx = target.getX() - player.getX();
        double dz = target.getZ() - player.getZ();
        double dy = target.getEyeY() - player.getEyeY();

        double dist = MathHelper.sqrt((float) (dx * dx + dz * dz));
        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        // Плавный поворот
        float currentYaw = player.getYaw();
        float currentPitch = player.getPitch();

        float newYaw = (float) (currentYaw + (targetYaw - currentYaw) * rotationSpeed);
        float newPitch = (float) (currentPitch + (targetPitch - currentPitch) * rotationSpeed);

        player.setYaw(newYaw);
        player.setPitch(newPitch);
    }
}