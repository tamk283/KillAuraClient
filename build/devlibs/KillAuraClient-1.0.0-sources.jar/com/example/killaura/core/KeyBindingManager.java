package com.example.killaura.core;

import com.example.killaura.gui.ClickGUI;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Менеджер горячих клавиш, отвечает за управление горячими клавишами.
 */
public class KeyBindingManager {
    private static final KeyBindingManager INSTANCE = new KeyBindingManager();
    private final MinecraftClient client;
    private KeyBinding openGuiKey;

    private KeyBindingManager() {
        client = MinecraftClient.getInstance();
        registerKeyBindings();
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    /**
     * Возвращает экземпляр KeyBindingManager.
     * @return экземпляр KeyBindingManager.
     */
    public static KeyBindingManager getInstance() {
        return INSTANCE;
    }

    /**
     * Регистрирует горячие клавиши.
     */
    private void registerKeyBindings() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.killaura.opengui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.killaura"
        ));
    }

    /**
     * Обрабатывает тики клиента.
     * @param client клиент Minecraft.
     */
    private void onTick(MinecraftClient client) {
        if (openGuiKey.wasPressed() && client.currentScreen == null) {
            // Открыть/закрыть меню
            if (ClickGUI.getInstance().isOpen()) {
                ClickGUI.getInstance().close();
            } else {
                ClickGUI.getInstance().open();
            }
        }
    }
}