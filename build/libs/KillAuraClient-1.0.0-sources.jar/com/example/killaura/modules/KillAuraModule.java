package com.example.killaura.modules;

import com.example.killaura.core.BaseModule;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public class KillAuraModule extends BaseModule {
    private final class_310 client;
    private class_1309 target;
    private long lastAttackTime = 0;
    private boolean isAttacking = false;

    private final double range = 4.5;
    private final double rotationSpeed = 0.5;
    private final boolean throughWalls = false;
    private final boolean onlyPlayers = true;
    private final long attackDelay = 200;

    public KillAuraModule() {
        super("KillAura", "Автоматическая атака ближайшего врага");
        this.client = class_310.method_1551();
        System.out.println("KillAuraModule created!");
    }

    @Override
    protected void onEnable() {
        System.out.println("KillAura ENABLED");
        isAttacking = true;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_30163("§aKillAura enabled!"), false);
        }
    }

    @Override
    protected void onDisable() {
        System.out.println("KillAura DISABLED");
        isAttacking = false;
        target = null;
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_30163("§cKillAura disabled!"), false);
        }
    }

    @Override
    protected void onUpdate() {
        if (client.field_1724 == null || client.field_1687 == null) return;

        // Включение/выключение по правому Shift
        if (client.field_1690.field_1832.method_1436()) {
            toggle();
            return;
        }

        if (!isAttacking) return;

        class_746 player = client.field_1724;

        // Поиск цели
        target = findTarget(player);

        if (target == null) return;

        // Поворот к цели
        rotateTo(player, target);

        // Атака с задержкой
        long now = System.currentTimeMillis();
        if (now - lastAttackTime < attackDelay) return;

        // Атака
        client.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);
        lastAttackTime = now;
    }

    private class_1309 findTarget(class_746 player) {
        List<class_1309> entities = new ArrayList<>();

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living)) continue;
            if (living == player) continue;
            if (!living.method_5805()) continue;
            if (living.method_6032() <= 0) continue;

            if (onlyPlayers && !(living instanceof class_1657)) continue;

            // Проверка через стены
            if (!throughWalls && !player.method_6057(living)) continue;

            // Дистанция
            double dist = player.method_5739(living);
            if (dist > range) continue;

            entities.add(living);
        }

        if (entities.isEmpty()) return null;

        entities.sort(Comparator.comparingDouble(e -> player.method_5739(e)));
        return entities.get(0);
    }

    private void rotateTo(class_746 player, class_1309 target) {
        double dx = target.method_23317() - player.method_23317();
        double dz = target.method_23321() - player.method_23321();
        double dy = target.method_23320() - player.method_23320();

        double dist = class_3532.method_15355((float) (dx * dx + dz * dz));
        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        // Плавный поворот
        float currentYaw = player.method_36454();
        float currentPitch = player.method_36455();

        float newYaw = (float) (currentYaw + (targetYaw - currentYaw) * rotationSpeed);
        float newPitch = (float) (currentPitch + (targetPitch - currentPitch) * rotationSpeed);

        player.method_36456(newYaw);
        player.method_36457(newPitch);
    }
}