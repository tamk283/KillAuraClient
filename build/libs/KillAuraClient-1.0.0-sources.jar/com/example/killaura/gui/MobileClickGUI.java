package com.example.killaura.gui;

import com.example.killaura.core.BaseModule;
import com.example.killaura.core.ModuleManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Адаптированное меню для мобильной версии.
 */
public class MobileClickGUI {
    private static final MobileClickGUI INSTANCE = new MobileClickGUI();
    private final class_310 client;
    private boolean open = false;
    private int selectedModuleIndex = 0;
    private final List<BaseModule> modules;

    private MobileClickGUI() {
        client = class_310.method_1551();
        modules = ModuleManager.getInstance().getAllModules();
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    /**
     * Возвращает экземпляр MobileClickGUI.
     * @return экземпляр MobileClickGUI.
     */
    public static MobileClickGUI getInstance() {
        return INSTANCE;
    }

    /**
     * Обрабатывает тики клиента.
     * @param client клиент Minecraft.
     */
    private void onTick(class_310 client) {
        if (client.field_1690.field_1822.method_1436()) {
            toggle();
        }

        if (open) {
            if (client.field_1690.field_1903.method_1436()) {
                selectedModuleIndex = (selectedModuleIndex - 1 + modules.size()) % modules.size();
            } else if (client.field_1690.field_1832.method_1436()) {
                selectedModuleIndex = (selectedModuleIndex + 1) % modules.size();
            } else if (client.field_1690.field_1886.method_1436()) {
                modules.get(selectedModuleIndex).toggle();
            }
        }
    }

    /**
     * Переключает состояние меню.
     */
    public void toggle() {
        open = !open;
    }

    /**
     * Рисует меню на экране (HUD).
     */
    public void render(class_332 drawContext, int width, int height) {
        if (!open || client.field_1724 == null) return;

        class_327 textRenderer = client.field_1772;

        // Рисуем полупрозрачный фон
        drawContext.method_25294(0, 0, width, height, 0x801a1a2e);

        // Рисуем список модулей
        int y = height / 2 - (modules.size() * 10) / 2;
        for (int i = 0; i < modules.size(); i++) {
            BaseModule module = modules.get(i);
            int color = i == selectedModuleIndex ? 0xFF00d4ff : 0xFFFFFFFF;
            String status = module.isEnabled() ? "[ON]" : "[OFF]";
            String text = status + " " + module.getName();
            drawContext.method_27535(textRenderer, class_2561.method_30163(text), width / 2 - textRenderer.method_1727(text) / 2, y, color);
            y += 20;
        }

        // Рисуем инструкции
        String instructions = "Jump: ↑ | Sneak: ↓ | Attack: Toggle";
        drawContext.method_27535(textRenderer, class_2561.method_30163(instructions), width / 2 - textRenderer.method_1727(instructions) / 2, height - 30, 0xFFFFFFFF);
    }
}