package com.example.killaura.gui;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class HudRenderer {
    private static boolean registered = false;

    public static void register() {
        if (registered) return;
        registered = true;

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            // Рендеринг меню
            MobileClickGUI.getInstance().render(drawContext, drawContext.method_51421(), drawContext.method_51443());
        });
    }
}