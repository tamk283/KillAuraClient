package com.example.killaura.gui;

import com.example.killaura.core.BaseModule;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Панель настроек модуля.
 */
public class SettingsPanel {
    private final ClickGUI parent;
    private BaseModule module;

    public SettingsPanel(ClickGUI parent) {
        this.parent = parent;
    }

    /**
     * Устанавливает модуль.
     * @param module модуль.
     */
    public void setModule(BaseModule module) {
        this.module = module;
    }

    /**
     * Рисует панель настроек.
     * @param context контекст отрисовки.
     * @param mouseX позиция курсора по оси X.
     * @param mouseY позиция курсора по оси Y.
     * @param delta время с последнего кадра.
     */
    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (module == null) return;

        // Рисуем фон панели настроек
        context.method_25294(10, 300, 610, 390, 0xFF1a1a2e);

        // Рисуем заголовок (исправлено)
        context.method_27535(
            class_310.method_1551().field_1772,
            class_2561.method_30163(module.getName()),
            20, 310, 0xFFFFFFFF
        );

        // TODO: Добавить отрисовку настроек модуля
    }

    /**
     * Обрабатывает клик мыши.
     * @param mouseX позиция курсора по оси X.
     * @param mouseY позиция курсора по оси Y.
     * @param button кнопка мыши.
     * @return true, если клик обработан.
     */
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return false;
    }

    /**
     * Обрабатывает отпускание кнопки мыши.
     * @param mouseX позиция курсора по оси X.
     * @param mouseY позиция курсора по оси Y.
     * @param button кнопка мыши.
     * @return true, если отпускание кнопки обработано.
     */
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return false;
    }
}