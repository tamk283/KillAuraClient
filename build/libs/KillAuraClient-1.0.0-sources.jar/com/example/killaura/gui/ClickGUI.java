package com.example.killaura.gui;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Основное меню клиента.
 */
public class ClickGUI extends class_437 {
    private static final ClickGUI INSTANCE = new ClickGUI();
    private boolean open = false;
    private CategoryPanel categoryPanel;
    private ModuleListPanel moduleListPanel;
    private SettingsPanel settingsPanel;
    private class_304 openGuiKey;
    private final class_310 field_22787;

    private ClickGUI() {
        super(class_2561.method_30163("ClickGUI"));
        field_22787 = class_310.method_1551();
        categoryPanel = new CategoryPanel(this);
        moduleListPanel = new ModuleListPanel(this);
        settingsPanel = new SettingsPanel(this);
        registerKeyBinding();
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    public static ClickGUI getInstance() {
        return INSTANCE;
    }

    private void registerKeyBinding() {
        openGuiKey = new class_304(
            "key.killaura.opengui",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.killaura"
        );
    }

    private void onTick(class_310 client) {
        if (openGuiKey.method_1436() && client.field_1755 == null && client.field_1724 != null && !client.field_1724.method_29504() && client.field_1761 != null && client.field_1761.method_2920() != class_1934.field_9220) {
            if (isOpen()) {
                method_25419();
            } else {
                open();
            }
        }
    }

    public void open() {
        if (field_22787 != null && field_22787.field_1755 == null && field_22787.field_1724 != null && !field_22787.field_1724.method_29504() && field_22787.field_1761 != null && field_22787.field_1761.method_2920() != class_1934.field_9220) {
            open = true;
            field_22787.method_1507(this);
        }
    }

    public void method_25419() {
        open = false;
        if (field_22787 != null) {
            field_22787.method_1507(null);
        }
    }

    public boolean isOpen() {
        return open;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (field_22787 == null) return;
        context.method_25294(0, 0, field_22787.method_22683().method_4486(), field_22787.method_22683().method_4502(), 0x801a1a2e);

        if (categoryPanel != null) categoryPanel.render(context, mouseX, mouseY, delta);
        if (moduleListPanel != null) moduleListPanel.render(context, mouseX, mouseY, delta);
        if (settingsPanel != null) settingsPanel.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (categoryPanel != null) categoryPanel.mouseClicked(mouseX, mouseY, button);
        if (moduleListPanel != null) moduleListPanel.mouseClicked(mouseX, mouseY, button);
        if (settingsPanel != null) settingsPanel.mouseClicked(mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (categoryPanel != null) categoryPanel.mouseReleased(mouseX, mouseY, button);
        if (moduleListPanel != null) moduleListPanel.mouseReleased(mouseX, mouseY, button);
        if (settingsPanel != null) settingsPanel.mouseReleased(mouseX, mouseY, button);
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (moduleListPanel != null) moduleListPanel.mouseScrolled(mouseX, mouseY, verticalAmount);
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public CategoryPanel getCategoryPanel() { return categoryPanel; }
    public ModuleListPanel getModuleListPanel() { return moduleListPanel; }
    public SettingsPanel getSettingsPanel() { return settingsPanel; }
}