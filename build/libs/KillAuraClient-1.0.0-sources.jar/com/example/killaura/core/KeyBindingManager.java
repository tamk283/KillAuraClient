package com.example.killaura.core;

import com.example.killaura.gui.ClickGUI;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Менеджер горячих клавиш, отвечает за управление горячими клавишами.
 */
public class KeyBindingManager {
    private static final KeyBindingManager INSTANCE = new KeyBindingManager();
    private final class_310 client;
    private class_304 openGuiKey;

    private KeyBindingManager() {
        client = class_310.method_1551();
        registerKeyBindings();
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    /**
     * Возвращает экземпляр KeyBindingManager.
     * @return экземпляр KeyBindingManager.
     */
    public static KeyBindingManager getInstance() {
        return INSTANCE;
    }

    /**
     * Регистрирует горячие клавиши.
     */
    private void registerKeyBindings() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.killaura.opengui",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.killaura"
        ));
    }

    /**
     * Обрабатывает тики клиента.
     * @param client клиент Minecraft.
     */
    private void onTick(class_310 client) {
        if (openGuiKey.method_1436() && client.field_1755 == null) {
            // Открыть/закрыть меню
            if (ClickGUI.getInstance().isOpen()) {
                ClickGUI.getInstance().method_25419();
            } else {
                ClickGUI.getInstance().open();
            }
        }
    }
}